This folder contains test data for use with the provided geoprcoessing scripts. All data is projected to World Geodetic System (WGS) 1984 Web Mercator Auxiliary Sphere (European Petroleum Survey Group [EPSG]:3857). These data are provided within the TestData.gdb Esri file geodatabase. 

Data descriptions and instructions for use:

BedrockDEM_WM - Subset of crystalline basement surface elevation raster used within this paper. Raster values are elevation (m) respective to mean sea level. Use within BoreholeProfile.py and SubsurfaceProfile.py.

dem1000m_WM - Subset of surface elevation raster used within this paper. Use within BoreholeProfile.py and SubsurfaceProfile.py.

intlwrclfkWMElevation - Lower Clear Fork salt deposit surface elevation model used within this paper. Use within BoreholeProfile.py and SubsurfaceProfile.py.

intnewhutWMElevation - New Hutchinson salt deposit surface elevation model used within this paper. Use within BoreholeProfile.py and SubsurfaceProfile.py.

profileschemaWM - Profile line used within SubsurfaceProfile.py.

SamplePoint - Point location used within BoreholeProfile.py.

SelectionPolygon - Selection polygon used within StressFieldsRoseDiagram.py.

StressFieldsUSA_WM - Subset of stress field data used within this paper. Use within StressFieldsRoseDiagram.py.


